<?php return array (
  'users.create-users' => 'App\\Http\\Livewire\\Users\\CreateUsers',
  'users.show-users' => 'App\\Http\\Livewire\\Users\\ShowUsers',
  'users.update-users' => 'App\\Http\\Livewire\\Users\\UpdateUsers',
);