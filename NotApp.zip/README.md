# NotApp
 Laravel web app for control of users,students, teachers and subjects
