<div>
    <p><?php echo e($open); ?></p>
    <button wire:click="$set('open', 'active')" class="ui tag violet label">Edit</button>

    <!-- Modal -->
    <?php if($open === 'active'): ?>

        <div class="ui dimmer modals page transition visible active" style="display: flex !important;">
            <div class="ui modal transition visible active" style="margin-top: -122px; display: block !important;">
                <div class="header">Actualizar usuario</div>
                <div class="content">

                    <form class="ui form segment">
                        <?php echo csrf_field(); ?>
                        <div class="two fields">
                            <div class="field">
                                <label>Name</label>
                                <input placeholder="First Name" type="text">
                            </div>
                            <div class="field">
                                <label>E-mail</label>
                                <input placeholder="E-mail" type="email">
                            </div>
                        </div>
                        <div class="field">
                            <div class="field">
                                <label>Estado</label>
                                <select class="ui dropdown">
                                    <option value="1">Active</option>
                                    <option value="2">Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="field">
                            <label>Perfil</label>
                            <select class="ui dropdown">
                                <option value="1">Admin</option>
                                <option value="2">Docente</option>

                            </select>
                        </div>
                        <div class="ui menu update" style="border: none;">
                            <div class="right menu">
                                <div class="item">
                                    <button wire:click="$set('open', 'hide')"
                                        class="ui right floated  purple inverted button">Cancelar</button>
                                </div>
                                <div class="item">
                                    <button type="submit" class="ui right floated  violet inverted button">Update
                                        user</button>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>

    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\NotApp\resources\views/livewire/users/update-users.blade.php ENDPATH**/ ?>