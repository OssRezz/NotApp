<div>
    <div class="ui raised segment">
        <a class="ui violet ribbon label"><i class="plus square inverted pink icon"></i>Usuarios</a>
        <span></i>Formulario de usuarios</span>
        <p></p>
    </div>

    <form class="ui form segment" wire:submit.prevent="save">
        <?php echo csrf_field(); ?>
        <div class="two fields">
            <div class="field">
                <label>Name</label>
                <input placeholder="First Name" wire:model.defer='nombre' type="text">
            </div>
            <div class="field">
                <label>E-mail</label>
                <input placeholder="E-mail" wire:model.defer='email' type="email">
            </div>
        </div>
        <div class="two fields">
            <div class="field">
                <label>Password</label>
                <input type="password" wire:model.defer='password'>
            </div>
            <div class="field">
                <label>Estado</label>
                <select wire:model.defer='estado' class="ui dropdown">
                    <option value="1" selected>choose an option...</option>
                    <option value="1">Active</option>
                    <option value="2">Inactive</option>
                </select>
            </div>
        </div>
        <div class="field">
            <label>Perfil</label>

            <select wire:model.defer='perfil' class="ui dropdown">
                <option value="1" selected>choose an option...</option>
                <option value="1">Admin</option>
                <option value="2">Docente</option>

            </select>
        </div>

        <br>
        <div class="field align-center">
            <button type="submit" class="ui  violet inverted button">Add user</button>
        </div>
    </form>
    
    <?php if($errors->any()): ?>
        <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['mensaje' => $errors]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if(session()->has('message')): ?>
        <div class="ui purple message">
            <i class="close icon"></i>
            <div class="header">
                <?php echo e(session('message')); ?>

            </div>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\NotApp\resources\views/livewire/users/create-users.blade.php ENDPATH**/ ?>