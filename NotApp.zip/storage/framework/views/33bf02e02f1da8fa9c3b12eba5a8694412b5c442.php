


<div>
    <div class="ui violet horizontal label">LiveWire</div>
    <div class="ui one item menu">
        <div class="ui left category search item">

            <div class="ui transparent icon input" style="padding-left: 0.2rem;">
                <input class="prompt" type="text" wire:model="search" placeholder="Search for users...">
                <div class="ui animated violet inverted  button" tabindex="0">
                    <div class="visible content">
                        <a href=""><i class="search link icon violet"></i></a>
                    </div>
                    <div class="hidden content">
                        <a href=""><i class="right arrow icon inverted"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php if($user->count()): ?>
        <table class="ui selectable striped  celled fixed  table">
            <thead>
                <tr>
                    <th wire:click="order('nombre')" style="cursor: pointer;">Nombre
                        
                        <?php if($sort == 'nombre'): ?>
                            <?php if($direction == 'asc'): ?>
                                <i class="sort up icon"></i>
                            <?php else: ?>
                                <i class="sort down icon"></i>
                            <?php endif; ?>

                        <?php else: ?>
                            <i class="sort icon"></i>
                        <?php endif; ?>
                    </th>
                    <th wire:click="order('email')" style="cursor: pointer;">Correo
                        <?php if($sort == 'email'): ?>
                            <?php if($direction == 'asc'): ?>
                                <i class="sort up icon"></i>
                            <?php else: ?>
                                <i class="sort down icon"></i>
                            <?php endif; ?>

                        <?php else: ?>
                            <i class="sort icon"></i>
                        <?php endif; ?>
                    </th>
                    <th wire:click="order('estado')" style="cursor: pointer;">Estado
                        <?php if($sort == 'estado'): ?>
                            <?php if($direction == 'asc'): ?>
                                <i class="sort up icon"></i>
                            <?php else: ?>
                                <i class="sort down icon"></i>
                            <?php endif; ?>

                        <?php else: ?>
                            <i class="sort icon"></i>
                        <?php endif; ?>
                    </th>
                    <th wire:click="order('id_perfil')" style="cursor: pointer;">Perfil
                        <?php if($sort == 'id_perfil'): ?>
                            <?php if($direction == 'asc'): ?>
                                <i class="sort up icon"></i>
                            <?php else: ?>
                                <i class="sort down icon"></i>
                            <?php endif; ?>

                        <?php else: ?>
                            <i class="sort icon"></i>
                        <?php endif; ?>
                    </th>
                    <th class="right aligned">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->nombre); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <?php
                            $estado = $user->estado === 1 ? 'Active' : 'Inactive';
                            $perfil = $user->id_perfil === 1 ? 'Admin' : 'Docente';
                        ?>
                        <td><?php echo e($estado); ?></td>
                        <td><?php echo e($perfil); ?></td>
                        <td class="right aligned">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('users.update-users', ['user' => $user])->html();
} elseif ($_instance->childHasBeenRendered($user->id)) {
    $componentId = $_instance->getRenderedChildComponentId($user->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($user->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($user->id);
} else {
    $response = \Livewire\Livewire::mount('users.update-users', ['user' => $user]);
    $html = $response->html();
    $_instance->logRenderedChild($user->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="ui violet iverted icon message">
            <i class="notched circle loading icon"></i>
            <div class="content">
                <div class="header">
                    Loading the bots...
                </div>
                <p>You should get a coffee cup.</p>
            </div>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\NotApp\resources\views/livewire/users/show-users.blade.php ENDPATH**/ ?>