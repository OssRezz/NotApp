
<?php $__env->startSection('title', 'Teachers'); ?>
<?php $__env->startSection('content'); ?>

    <div class="pusher">
        <div class="ui  grid">

            <div class="row">
                <div class="column">
                    <div class="container">
                        <div class="ui menu purple inverted menuTop">
                            <a href="#" class="item" id="btnHb"><i class="bars icon"></i></a>
                            <div class="item" id=""><?php echo e(Auth::user()->nombre); ?></div>
                            <div class="item right">
                                <form action="users/logout" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <a href="#" class="ui violet  button" onclick="this.closest('form').submit()"><i
                                            class="sign-out alternate icon"></i>Log-out
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="two column stackable row centered">
                <div class="one column">
                    <div class="container">

                        <table class="ui selectable  celled fixed  table">

                            <thead>
                                <tr>
                                    <th>ID teacher</th>
                                    <th>Name</th>
                                    <th>Subject</th>
                                    <th>Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($teacher->cc_teacher); ?></td>
                                        <td><?php echo e($teacher->teacher); ?></td>
                                        <td><?php echo e($teacher->nombre); ?></td>
                                        <td class="center aligned">
                                            <div class="inline aligned">
                                                <a href="<?php echo e(route('teacher.edit', $teacher)); ?>"><i
                                                        class="purple edit outline link icon"></i></a>
                                                <a href="<?php echo e(route('teacher.edit', $teacher)); ?>"><i
                                                        class="pink trash link icon"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="ui right aligned container">
                            <span><?php echo e($teachers->links('vendor/pagination/semantic-ui', ['paginator' => $teachers])); ?></span>
                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NotApp\resources\views/teacher/searchteacher.blade.php ENDPATH**/ ?>