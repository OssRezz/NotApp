
<?php $__env->startSection('title', 'Users edit'); ?>

<?php $__env->startSection('content'); ?>



    <div class="pusher">
        <div class="ui  grid">

            <div class="row">
                <div class="column">
                    <div class="container">
                        <div class="ui menu purple inverted menuTop">
                            <a href="#" class="item" id="btnHb"><i class="bars icon"></i></a>
                            <div class="item" id=""><?php echo e(Auth::user()->nombre); ?></div>
                            <div class="item right">
                                <form action="users/logout" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <a href="#" class="ui violet  button" onclick="this.closest('form').submit()"><i
                                            class="sign-out alternate icon"></i>Log-out
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="two column stackable row centered">
                <div class="one column">
                    <div class="container">

                        <div class="ui segment">
                            <div class="ui raised segment">
                                <a class="ui violet ribbon label"><i class="plus square inverted pink icon"></i>Usuarios</a>
                                <span></i>Editar usuarios</span>
                                <p></p>
                            </div>

                            <form class="ui form segment" action="<?php echo e(route('users.update', $user)); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                
                                <?php echo method_field('put'); ?>

                                <div class="two fields">
                                    <div class="field">
                                        <label>Name</label>
                                        <input placeholder="First Name" name="nombre" value="<?php echo e($user->nombre); ?>"
                                            type="text">
                                    </div>
                                    <div class="field">
                                        <label>E-mail</label>
                                        <input placeholder="E-mail" name="email" value="<?php echo e($user->email); ?>" type="email">
                                    </div>
                                </div>
                                <div class="two fields">
                                    <div class="field">
                                        <label>Profile</label>
                                        <select name='perfil' class="ui dropdown">

                                            <?php
                                                $user_profileId = $userProfile->id;
                                                $user_profileName = $userProfile->perfil;
                                            ?>

                                            <option value="<?php echo e($user_profileId); ?>"><?php echo e($user_profileName); ?></option>

                                            <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profiles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($user_profileId != $profiles->id): ?>
                                                    <option value="<?php echo e($profiles->id); ?>"><?php echo e($profiles->perfil); ?></option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>

                                    <div class="field">
                                        <label>State</label>
                                        <select name='estado' class="ui dropdown">

                                            <?php
                                                
                                            ?>
                                            <?php if($user->estado === 1): ?>
                                                <option value="1">Active</option>
                                                <option value="2">Inactive</option>
                                            <?php else: ?>
                                                <option value="2">Inactive</option>
                                                <option value="1">Active</option>
                                            <?php endif; ?>


                                        </select>
                                    </div>


                                </div>


                                <br>
                                <div class="field align-center">
                                    <input class="ui  violet inverted button" type="submit" value="Update user">
                                </div>


                            </form>
                            <?php if($errors->any()): ?>
                                <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['mensaje' => $errors]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <?php if(session()->has('message')): ?>
                                <div class="ui violet message">
                                    <i class="close icon"></i>
                                    <div class="header">
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NotApp\resources\views/user/editusers.blade.php ENDPATH**/ ?>