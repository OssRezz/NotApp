<div>
    <div class="ui purple message">
        <i class="close icon"></i>
        <div class="header">
            <?php if(is_object($mensaje)): ?>
                <?php $__currentLoopData = $mensaje->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <?php echo e($mensaje); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\NotApp\resources\views/components/alert.blade.php ENDPATH**/ ?>